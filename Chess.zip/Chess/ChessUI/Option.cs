﻿namespace ChessUI
{
    public enum Option
    {
        History,
        Exit,
        Continue
    }
}