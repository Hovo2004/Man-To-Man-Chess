﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ChessLogic;

namespace ChessUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private PieceType PawnPromotionType = PieceType.None;
        private string moveHistory;
        private int moveCount;
        private int time = 1;
        private bool flag1;
        private int MoveCount;
        private int timeInSeconds1;
        private bool isTimerRunning1;
        private bool stopRequested1;
        private Task timerTask1;
        private DateTime startTime1;
        private TimeSpan elapsedTime1;

        // Second Timer Variables
        private bool StopFlag;
        private bool flag2;
        private int timeInSeconds2;
        private bool isTimerRunning2;
        private bool stopRequested2;
        private Task timerTask2;
        private DateTime startTime2;
        private TimeSpan elapsedTime2;


        private readonly Image[,] pieceImages = new Image[8, 8];
        private readonly Rectangle[,] highlights = new Rectangle[8, 8];
        private readonly Dictionary<Position, Move> moveCache = [];

        private GameState gameState;
        private BackForwardMatrix backForwardMatrix = new();
        private Position selectedPos = null;
        public MainWindow()
        {
            InitializeComponent();
            InitializeBoard();
            gameState = new GameState(Player.White, Board.Initial());
            DrawBoard(gameState.Board);
            History.IsEnabled = false;
        }

        private void InitializeBoard()
        {
            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    Image image = new();
                    pieceImages[r, c] = image;
                    PieceGrid.Children.Add(image);

                    Rectangle highlight = new();
                    highlights[r, c] = highlight;
                    HighlightGrid.Children.Add(highlight);
                }
            }
        }

        private void DrawBoard(Board board)
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Piece piece = board[i, j];
                    pieceImages[i, j].Source = Images.GetImage(piece);
                }
            }
        }

        private void BoardGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (IsMenuOnScreen())
            {
                return;
            }
            Point point = e.GetPosition(BoardGrid);
            Position pos = ToSquarePosition(point);

            if (selectedPos == null)
            {
                OnFromPositionSelected(pos);
            }
            else
            {
                OnToPositionSelected(pos);
            }
        }

        private Position ToSquarePosition(Point point)
        {
            double squareSize = BoardGrid.ActualWidth / 8;
            int row = (int)(point.Y / squareSize);
            int col = (int)(point.X / squareSize);
            return new Position(row, col);
        }

        private void OnFromPositionSelected(Position pos)
        {
            IEnumerable<Move> moves = gameState.LegalMovesForPiece(pos);

            if (moves.Any())
            {
                selectedPos = pos;
                CacheMoves(moves);
                ShowHighlights();
            }
        }

        private void OnToPositionSelected(Position pos)
        {
            selectedPos = null;
            HideHighlights();

            if (moveCache.TryGetValue(pos, out Move move))
            {

                if (move.Type == MoveType.PawnPromotion)
                {
                    HandlePromotion(move.FromPos, move.ToPos);
                }
                else
                {
                    HandleMove(move);
                }
            }
            
            
        }

        private void HandlePromotion(Position from, Position to)
        {
            
            pieceImages[to.Row, to.Column].Source = Images.GetImage(gameState.CurrentPlayer, PieceType.Pawn);
            pieceImages[from.Row, from.Column].Source = null;

            PromotionMenu promMenu = new(gameState.CurrentPlayer);
            MenuContainer.Content = promMenu;

            promMenu.PieceSelected += type => {
                MenuContainer.Content = null;
                backForwardMatrix.GetPawnType(moveCount, type);
                PawnPromotionType = type;
                Move promMove = new PawnPromotion(from, to, type);
                HandleMove(promMove);
            };
        }

        private string PieceChar(PieceType type)
        {
            return type switch
            {
                PieceType.Queen => "Q",
                PieceType.King => "K",
                PieceType.Knight => "N",
                PieceType.Rook => "R",
                PieceType.Bishop => "B",
                _ => "P"
            };
        }

        private bool IsEating(Move move, Board board)
        {
            return board[move.ToPos] != null;
        }
        private string ConvertPositionToString(Position pos)
        {

            string Row = (8 - pos.Row).ToString();
            string Column = pos.Column switch
            {
                0 => "a",
                1 => "b",
                2 => "c",
                3 => "d",
                4 => "e",
                5 => "f",
                6 => "g",
                _ => "h"
            };

            return Column + Row;

        }

        private string MoveHistoryCreator(Move move, Board board, PieceType type, bool isGameOver, PieceType pawnPromotion = PieceType.None)
        {
            string moveIdentifier = "";

            if (move.Type == MoveType.CastleKS)
            {
                moveIdentifier += "O-O";
            }
            else if (move.Type == MoveType.CastleQS)
            {
                moveIdentifier += "O-O-O";
            }
            else if (type == PieceType.Pawn)
            {
                if (IsEating(move, board))
                {
                    string Column = move.FromPos.Column switch
                    {
                        0 => "a",
                        1 => "b",
                        2 => "c",
                        3 => "d",
                        4 => "e",
                        5 => "f",
                        6 => "g",
                        _ => "h"
                    };
                    moveIdentifier += Column + "x";
                }
                moveIdentifier += ConvertPositionToString(move.ToPos);
            }
            else
            {
                moveIdentifier += PieceChar(type);
                if (IsEating(move, board))
                {
                    moveIdentifier += "x";
                }
                moveIdentifier += ConvertPositionToString(move.ToPos);
            }

            if (pawnPromotion != PieceType.None)
            {
                moveIdentifier += PieceChar(pawnPromotion);
            }

            gameState.MakeMove(move, time);
            History.IsEnabled = true;
            if (board.IsInCheck(gameState.CurrentPlayer) || board.IsInCheck(gameState.CurrentPlayer.Opponent()))
            {
                if (isGameOver)
                {
                    moveIdentifier += "#";
                }
                else
                {
                    moveIdentifier += "+";
                }
            }

            return moveIdentifier;

        }

        private void MoveHistoryAdd(Move move, Board board, PieceType type, bool isGameOver, PieceType pawnPromotion = PieceType.None)
        {
            
            if (moveCount % 2 == 0)
            {
                moveHistory += "  " + ((int)moveCount / 2 + 1).ToString() + MoveHistoryCreator(move, board, type, isGameOver, pawnPromotion);
            }
            else
            {
                moveHistory += " " + MoveHistoryCreator(move, board, type, isGameOver, pawnPromotion);
            }
            

        }

        private void HandleMove(Move move)
        {
            
            Piece piecetype = gameState.Board[move.FromPos];
            MoveHistoryAdd(move, gameState.Board, piecetype.Type, gameState.IsGameOver(), PawnPromotionType);
            backForwardMatrix.GetPos(move, moveCount, gameState, moveHistory);
            moveCount++;
            DrawBoard(gameState.Board);
            
            PawnPromotionType = PieceType.None;
            History.IsEnabled = true;
            if (MoveCount % 2 == 0)
            {
                if(!StopFlag)
                {
                    timerComboBox1.IsEnabled = false;
                    Resume1();
                    StopFlag = true;
                }
                else
                {
                    Stop2();
                    Resume1();
                }
            }
            else
            {
                Stop1();
                Resume2();
            }
            MoveCount++;

            if (gameState.IsGameOver())
            {
                ShowGameOver();
            }
        }

        private void CacheMoves(IEnumerable<Move> moves)
        {
            moveCache.Clear();

            foreach(Move move in moves)
            {
                moveCache[move.ToPos] = move;
            }
        }


        

        private void ShowHighlights()
        {
            Color color = Color.FromArgb(150, 125, 255, 125);

            foreach (Position to in moveCache.Keys)
            {
                highlights[to.Row, to.Column].Fill = new SolidColorBrush(color);
            }
        }

        private void HideHighlights()
        {
            foreach(Position to in moveCache.Keys)
            {
                highlights[to.Row, to.Column].Fill = Brushes.Transparent;
            }
        }

        private bool IsMenuOnScreen()
        {
            return MenuContainer.Content != null;
        }

        private void ShowGameOver()
        {
            GameOverMenu gameOverMenu = new(gameState);
            MenuContainer.Content = gameOverMenu;

            gameOverMenu.OptionSelected += option =>
            {
                
                Application.Current.Shutdown();
                
            };
        }

        public void ShowHistory()
        {
            BackAndForward backAndForward = new(backForwardMatrix,gameState);
            MenuContainer.Content = backAndForward;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (!IsMenuOnScreen() && e.Key == Key.Escape)
            {
                ShowPauseMenu();
            }
        }

        private void ShowPauseMenu()
        {


            PauseMenu pauseMenu = new();
            MenuContainer.Content = pauseMenu;

            pauseMenu.OptionSelected += option => {
                MenuContainer.Content = null;
            };
        }

        private void Stop1()
        {
            isTimerRunning1 = false;
            stopRequested1 = true;
            elapsedTime1 = DateTime.Now - startTime1;
        }

        private async void Resume1()
        {
            
            isTimerRunning1 = true;
            stopRequested1 = false;
            startTime1 = DateTime.Now;

            if (!flag1)
            {
                timerTask1 = Task.Run(() => RunTimer1(elapsedTime1));
                flag1 = true;
            }
            else
            {
                if (elapsedTime1 > TimeSpan.Zero)
                {
                    timeInSeconds1 -= (int)elapsedTime1.TotalSeconds;
                    timerTask1 = Task.Run(() => RunTimer1());
                    await timerTask1;
                }
                else
                {
                    timerTask1 = Task.Run(() => RunTimer1());
                    await timerTask1;
                }

            }
        }

        private void Stop2()
        {
            isTimerRunning2 = false;
            stopRequested2 = true;
            elapsedTime2 = DateTime.Now - startTime2;
        }
        private async void Resume2()
        {
            
            isTimerRunning2 = true;
            stopRequested2 = false;
            startTime2 = DateTime.Now;

            if (!flag2)
            {
                timerTask2 = Task.Run(() => RunTimer2(elapsedTime2));
                flag2 = true;
            }
            else
            {
                if (elapsedTime2 > TimeSpan.Zero)
                {
                    timeInSeconds2 -= (int)elapsedTime2.TotalSeconds;
                    timerTask2 = Task.Run(() => RunTimer2());
                    await timerTask2;
                }
                else
                {
                    timerTask2 = Task.Run(() => RunTimer2());
                    await timerTask2;
                }
            }
        }

       

        private void RunTimer1(TimeSpan? initialElapsedTime = null)
        {
            int timeLeft = timeInSeconds1;

            if (initialElapsedTime.HasValue)
            {
                timeLeft -= (int)initialElapsedTime.Value.TotalSeconds;
            }

            while (timeLeft > 0 && isTimerRunning1 && !stopRequested1)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    TimeSpan remainingTime = TimeSpan.FromSeconds(timeLeft);
                    timerTextBlock1.Text = $"{remainingTime.Minutes:00}:{remainingTime.Seconds:00}";
                });

                System.Threading.Thread.Sleep(1000);
                timeLeft--;
            }

            if (timeLeft == 0)
            {
                time = 0;
                gameState.CheckForGameOver(time);
                Application.Current.Dispatcher.Invoke(() =>
                {
                    ShowGameOver();
                });

            }
        }

        private void RunTimer2(TimeSpan? initialElapsedTime = null)
        {
            int timeLeft = timeInSeconds2;

            if (initialElapsedTime.HasValue)
            {
                timeLeft -= (int)initialElapsedTime.Value.TotalSeconds;
            }

            while (timeLeft > 0 && isTimerRunning2 && !stopRequested2)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    TimeSpan remainingTime = TimeSpan.FromSeconds(timeLeft);
                    timerTextBlock2.Text = $"{remainingTime.Minutes:00}:{remainingTime.Seconds:00}";
                });

                System.Threading.Thread.Sleep(1000);
                timeLeft--;
            }

            if (timeLeft == 0)
            {
                time = 0;
                gameState.CheckForGameOver(time);
                Application.Current.Dispatcher.Invoke(() =>
                {
                    ShowGameOver();
                });
                

                


            }
        }

        private void timerComboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            isTimerRunning1 = false;
            isTimerRunning2 = false;
            stopRequested1 = false;
            stopRequested2 = false;
            timerTextBlock1.Foreground = Brushes.White;
            timerTextBlock2.Foreground = Brushes.White;
            
            timeInSeconds1 = Convert.ToInt32(((ComboBoxItem)timerComboBox1.SelectedItem).Tag);
            timeInSeconds2 = Convert.ToInt32(((ComboBoxItem)timerComboBox1.SelectedItem).Tag);
            //timerComboBox1.IsEnabled = false;
            TimeSpan remainingTime1 = TimeSpan.FromSeconds(timeInSeconds1);
            timerTextBlock1.Text = $"{remainingTime1.Minutes:00}:{remainingTime1.Seconds:00}";

            TimeSpan remainingTime2 = TimeSpan.FromSeconds(timeInSeconds2);
            timerTextBlock2.Text = $"{remainingTime2.Minutes:00}:{remainingTime2.Seconds:00}";
        }

        private void History_Click(object sender, RoutedEventArgs e)
        {
            ShowHistory();
            History.IsEnabled = false;
        }

        private void Close1_Click(object sender, RoutedEventArgs e)
        {
           
            History.IsEnabled = true;
            MenuContainer.Content = null;
        }
    }
}