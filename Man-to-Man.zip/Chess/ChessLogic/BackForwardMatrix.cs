﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessLogic
{
    public class BackForwardMatrix 
    {
        public string moveHistory;
        public int moveCount;
        public Dictionary<int, Piece> eatenPieces = [];
        public Dictionary<int, PieceType> pawnPromotionPiece = [];
        public List<Move> Moves = [];

        public void GetPos(Move move, int moveCount, GameState gameState)
        {
            
            this.moveCount = moveCount;
            if (gameState.Board[move.ToPos] != null)
            {
                eatenPieces[moveCount] = gameState.Board[move.ToPos];
            }
            Moves.Add(move);
        }
        public void MakeHistory(string moveHistory)
        {
            this.moveHistory = moveHistory;
        }
        public void GetPawnType(int moveCount, PieceType type)
        {
            pawnPromotionPiece[moveCount] = type;
        }
    }
}
