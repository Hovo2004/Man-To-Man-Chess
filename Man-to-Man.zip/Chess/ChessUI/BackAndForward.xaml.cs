﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ChessLogic;

namespace ChessUI
{
    /// <summary>
    /// Interaction logic for BackAndForward.xaml
    /// </summary>
    
    public partial class BackAndForward : UserControl
    {

        private Dictionary<int, Piece> eatenPieces = [];
        private readonly Image[,] pieceImages;
        private readonly GameState gameState;
        private readonly Board board;
        private Player CurrentPlayer;
        private int index;
        private int moveCount;
        private readonly BackForwardMatrix matrix;
        public BackAndForward(BackForwardMatrix matrix, GameState gameState)
        {
            

            moveCount = matrix.moveCount;
            index = matrix.moveCount;
            this.matrix = matrix;
            this.gameState = new GameState(gameState.CurrentPlayer.Opponent(), gameState.Board);
            board = this.gameState.Board.Copy();
            CurrentPlayer = this.gameState.CurrentPlayer.Opponent();
            this.pieceImages = new Image[8, 8];
            eatenPieces = matrix.eatenPieces;
            InitializeComponent();
            if (index == 0)
            {
                Back.IsEnabled = false;
            }
            InitializeBoard();
            MoveHistory.Items.Add(matrix.moveHistory);
            
        }

        private void InitializeBoard()
        {
            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    Image image = new();
                    pieceImages[r, c] = image;
                    PieceGrid1.Children.Add(image);
                }
            }

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Piece piece = board[i, j];
                    pieceImages[i, j].Source = Images.GetImage(piece);
                }
            }
        }

        private static bool HasBeenPiece(BackForwardMatrix matrix, int index)
        {
            foreach (int i in matrix.eatenPieces.Keys)
            {
                if (i == index) return true;
            }
            return false;
        }
        
        private void DrawBoard()
        {
            for (int i = 0; i< 8;i++)
            {
                for(int j = 0;j < 8; j++)
                {
                    pieceImages[i, j].Source = Images.GetImage(board[i,j]);
                }
            }
        }
        private void BackMove()
        {
            if (matrix.Moves[index].Type == MoveType.CastleKS)
            {
                int Row = matrix.Moves[index].FromPos.Row;
                board[Row, 4] = board[Row, 6];
                board[Row, 6] = null;
                board[Row, 7] = board[Row, 5];
                board[Row, 5] = null;
                pieceImages[Row, 4].Source = Images.GetImage(board[Row, 4]);
                pieceImages[Row, 6].Source = null;
                pieceImages[Row, 7].Source = Images.GetImage(board[Row, 7]);
                pieceImages[Row, 5].Source = null;
            }
            else if (matrix.Moves[index].Type == MoveType.CastleQS)
            {
                int Row = matrix.Moves[index].FromPos.Row;
                board[Row, 4] = board[Row, 2];
                board[Row, 2] = null;
                board[Row, 0] = board[Row, 3];
                board[Row, 3] = null;
                pieceImages[Row, 4].Source = Images.GetImage(board[Row, 4]);
                pieceImages[Row, 2].Source = null;
                pieceImages[Row, 0].Source = Images.GetImage(board[Row, 0]);
                pieceImages[Row, 3].Source = null;
            }
            else if (matrix.Moves[index].Type == MoveType.EnPassant)
            {               
                Position FromPos = matrix.Moves[index].ToPos;
                Position ToPos = matrix.Moves[index].FromPos;
                Piece x = board[FromPos];
                Piece y = new Pawn(CurrentPlayer);
                board[FromPos] = null;
                pieceImages[FromPos.Row,FromPos.Column].Source = null;
                board[ToPos.Row, FromPos.Column] = y;
                board[ToPos] = x;
                pieceImages[ToPos.Row, ToPos.Column].Source = Images.GetImage(x);
                pieceImages[FromPos.Row, FromPos.Column].Source = null;
                pieceImages[ToPos.Row, FromPos.Column].Source = Images.GetImage(board[ToPos.Row, FromPos.Column]);
                
            }
            else
            {

                Position FromPos = matrix.Moves[index].ToPos;
                Position ToPos = matrix.Moves[index].FromPos;
                Piece x = board[FromPos];
                if (matrix.Moves[index].Type == MoveType.PawnPromotion)
                {
                    x = new Pawn(CurrentPlayer.Opponent());
                }
                if (HasBeenPiece(matrix, index))
                {
                    board[FromPos] = eatenPieces[index];
                    pieceImages[FromPos.Row, FromPos.Column].Source = Images.GetImage(board[FromPos]);
                    board[ToPos] = x;
                    pieceImages[ToPos.Row, ToPos.Column].Source = Images.GetImage(x);
                    
                }
                else
                {
                    board[FromPos] = null;
                    pieceImages[FromPos.Row, FromPos.Column].Source = null;
                    board[ToPos] = x;
                    pieceImages[ToPos.Row, ToPos.Column].Source = Images.GetImage(x);
                    
                    
                }
                

            }
            CurrentPlayer = CurrentPlayer.Opponent();

            DrawBoard();
            if (index == 0)
            {
                Back.IsEnabled = false;
            }
            else
            {
                Forward.IsEnabled = true;
            }
            index--;
        }
        private Piece CreatePromotionPiece(Player color, PieceType newType)
        {
            return newType switch
            {
                PieceType.Knight => new Knight(color),
                PieceType.Bishop => new Bishop(color),
                PieceType.Rook => new Rook(color),
                _ => new Queen(color)
            };
        }
        private void ForwardMove()
        {
            index++;

            Position FromPos = matrix.Moves[index].FromPos;
            Position ToPos = matrix.Moves[index].ToPos;

            if (matrix.Moves[index].Type == MoveType.PawnPromotion)
            {
                PieceType pawnPromotionType = matrix.pawnPromotionPiece[index];
                Piece pawnPromotionPiece = CreatePromotionPiece(CurrentPlayer, pawnPromotionType);
                board[FromPos] = null;
                board[ToPos] = pawnPromotionPiece;
                pieceImages[FromPos.Row, FromPos.Column].Source = null;
                pieceImages[ToPos.Row, ToPos.Column].Source = Images.GetImage(pawnPromotionPiece);
            }
            else if (matrix.Moves[index].Type == MoveType.CastleKS)
            {
                int Row = matrix.Moves[index].FromPos.Row;
                board[Row, 6] = board[Row, 4];
                board[Row, 4] = null;
                board[Row, 5] = board[Row, 7];
                board[Row, 7] = null;
                pieceImages[Row, 6].Source = Images.GetImage(board[Row, 6]);
                pieceImages[Row, 4].Source = null;
                pieceImages[Row, 5].Source = Images.GetImage(board[Row, 5]);
                pieceImages[Row, 7].Source = null;
            }
            else if (matrix.Moves[index].Type == MoveType.CastleQS)
            {
                int Row = matrix.Moves[index].FromPos.Row;
                board[Row, 2] = board[Row, 4];
                board[Row, 4] = null;
                board[Row, 3] = board[Row, 0];
                board[Row, 0] = null;
                pieceImages[Row, 2].Source = Images.GetImage(board[Row, 2]);
                pieceImages[Row, 4].Source = null;
                pieceImages[Row, 3].Source = Images.GetImage(board[Row, 3]);
                pieceImages[Row, 0].Source = null;
            }
            else if (matrix.Moves[index].Type == MoveType.EnPassant)
            {
                Piece x = board[FromPos];
                Piece y = new Pawn(CurrentPlayer);
                board[FromPos.Row, ToPos.Column] = null;
                board[ToPos] = board[FromPos];
                board[FromPos] = null;
                pieceImages[ToPos.Row, ToPos.Column].Source = Images.GetImage(x);
                pieceImages[FromPos.Row, ToPos.Column].Source = null;
                pieceImages[FromPos.Row, FromPos.Column].Source = null;
            }
            else
            {
                board[ToPos] = board[FromPos];
                board[FromPos] = null;
                pieceImages[FromPos.Row, FromPos.Column].Source = null;
                pieceImages[ToPos.Row, ToPos.Column].Source = Images.GetImage(board[ToPos]);
                
            }

            CurrentPlayer = CurrentPlayer.Opponent();
            if (index == moveCount)
            {
                Forward.IsEnabled = false;
            }
            else
            {
                Back.IsEnabled= true;
            }
        }
        

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            BackMove();
        }

        private void Forward_Click(object sender, RoutedEventArgs e)
        {
            if (index == moveCount)
            {
                Forward.IsEnabled = false;
            }
            else
            {
                ForwardMove();

            }

        }      
    }
}
